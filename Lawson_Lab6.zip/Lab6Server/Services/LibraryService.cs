﻿using System;
using System.Collections.Generic;

namespace Lab6Server.Services
{
    public class LibraryService
    {
        public Dictionary<int, User> Users { get; } = new Dictionary<int, User>();
        public Dictionary<int, Book> Books { get; } = new Dictionary<int, Book>();
        public Dictionary<int, List<int>> Borrowings { get; } = new Dictionary<int, List<int>>();

        public void AddUser(string name, string email)
        {
            int userId = GenerateUserId();
            Users[userId] = new User { UserId = userId, Name = name, Email = email };
        }

        public void EditUser(int userId, string newName, string newEmail)
        {
            if (Users.ContainsKey(userId))
            {
                User user = Users[userId];
                user.Name = newName;
                user.Email = newEmail;
            }
        }

        public void DeleteUser(int userId)
        {
            Users.Remove(userId);
        }

        public List<User> ListUsers()
        {
            return new List<User>(Users.Values);
        }

        public void AddBook(string title, string author, string isbn)
        {
            int bookId = GenerateBookId();
            Books[bookId] = new Book { BookId = bookId, Title = title, Author = author, ISBN = isbn };
        }

        public void EditBook(int bookId, string newTitle, string newAuthor, string newIsbn)
        {
            if (Books.ContainsKey(bookId))
            {
                Book book = Books[bookId];
                book.Title = newTitle;
                book.Author = newAuthor;
                book.ISBN = newIsbn;
            }
        }

        public void DeleteBook(int bookId)
        {
            Books.Remove(bookId);
        }

        public List<Book> ListBooks()
        {
            return new List<Book>(Books.Values);
        }

        public void BorrowBook(int userId, int bookId)
        {
            if (Users.ContainsKey(userId) && Books.ContainsKey(bookId))
            {
                if (!Borrowings.ContainsKey(userId))
                {
                    Borrowings[userId] = new List<int>();
                }

                Borrowings[userId].Add(bookId);
            }
        }

        public void ReturnBook(int userId, int bookId)
        {
            if (Borrowings.ContainsKey(userId))
            {
                Borrowings[userId].Remove(bookId);
            }
        }

        public List<int> DisplayBorrows(int userId)
        {
            return Borrowings.ContainsKey(userId) ? new List<int>(Borrowings[userId]) : new List<int>();
        }

        private int GenerateUserId()
        {
            return Users.Count + 1;
        }

        private int GenerateBookId()
        {
            return Books.Count + 1;
        }
    }

    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }

    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
    }
}
